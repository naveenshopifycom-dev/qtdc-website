// Advanced Animation Controller for QuickThink DotCom

class AnimationController {
    constructor() {
        this.animations = new Map();
        this.observers = new Map();
        this.init();
    }

    init() {
        this.setupScrollAnimations();
        this.setupHoverAnimations();
        this.setupParallaxEffects();
        this.setupParticleSystem();
    }

    // Scroll-triggered animations
    setupScrollAnimations() {
        const scrollElements = document.querySelectorAll('[data-animate]');
        
        const scrollObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const animationType = entry.target.dataset.animate;
                    const delay = entry.target.dataset.delay || 0;
                    
                    setTimeout(() => {
                        this.playAnimation(entry.target, animationType);
                    }, delay);
                    
                    scrollObserver.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -10px 0px'
        });

        scrollElements.forEach(el => scrollObserver.observe(el));
    }

    // Hover animations
    setupHoverAnimations() {
        const hoverElements = document.querySelectorAll('[data-hover]');
        
        hoverElements.forEach(element => {
            const hoverType = element.dataset.hover;
            
            element.addEventListener('mouseenter', () => {
                this.playHoverAnimation(element, hoverType, 'enter');
            });
            
            element.addEventListener('mouseleave', () => {
                this.playHoverAnimation(element, hoverType, 'leave');
            });
        });
    }

    // Parallax effects
    setupParallaxEffects() {
        const parallaxElements = document.querySelectorAll('[data-parallax]');
        
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            
            parallaxElements.forEach(element => {
                const speed = parseFloat(element.dataset.parallax) || 0.5;
                const yPos = -(scrolled * speed);
                element.style.transform = `translate3d(0, ${yPos}px, 0)`;
            });
        });
    }

    // Particle system
    setupParticleSystem() {
        const particleContainers = document.querySelectorAll('.particles-container');
        
        particleContainers.forEach(container => {
            this.createParticles(container);
        });
    }

    createParticles(container) {
        const particleCount = parseInt(container.dataset.particles) || 50;
        
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            
            const size = Math.random() * 4 + 2;
            const x = Math.random() * 100;
            const duration = Math.random() * 20 + 10;
            const delay = Math.random() * 5;
            
            particle.style.cssText = `
                position: absolute;
                left: ${x}%;
                width: ${size}px;
                height: ${size}px;
                background: radial-gradient(circle, #8b5cf6, #ec4899);
                border-radius: 50%;
                opacity: ${Math.random() * 0.8 + 0.2};
                animation: particleFloat ${duration}s linear infinite;
                animation-delay: ${delay}s;
            `;
            
            container.appendChild(particle);
        }
    }

    // Play specific animation
    playAnimation(element, type) {
        element.classList.remove('animate-' + type);
        
        // Trigger reflow
        element.offsetHeight;
        
        element.classList.add('animate-' + type);
    }

    // Play hover animation
    playHoverAnimation(element, type, phase) {
        switch (type) {
            case 'lift':
                if (phase === 'enter') {
                    element.style.transform = 'translateY(-8px)';
                    element.style.boxShadow = '0 25px 50px rgba(0, 0, 0, 0.25)';
                } else {
                    element.style.transform = '';
                    element.style.boxShadow = '';
                }
                break;
                
            case 'scale':
                if (phase === 'enter') {
                    element.style.transform = 'scale(1.05)';
                } else {
                    element.style.transform = '';
                }
                break;
                
            case 'rotate':
                if (phase === 'enter') {
                    element.style.transform = 'rotate(5deg)';
                } else {
                    element.style.transform = '';
                }
                break;
                
            case 'glow':
                if (phase === 'enter') {
                    element.style.boxShadow = '0 0 20px rgba(139, 92, 246, 0.4)';
                } else {
                    element.style.boxShadow = '';
                }
                break;
        }
    }

    // Staggered animations
    staggerAnimation(elements, animationType, staggerDelay = 100) {
        elements.forEach((element, index) => {
            setTimeout(() => {
                this.playAnimation(element, animationType);
            }, index * staggerDelay);
        });
    }

    // Morphing shapes
    createMorphingShape(container) {
        const shape = document.createElement('div');
        shape.className = 'morphing-shape';
        shape.style.cssText = `
            width: 200px;
            height: 200px;
            background: linear-gradient(45deg, #8b5cf6, #ec4899, #3b82f6);
            background-size: 300% 300%;
            animation: morph 8s ease-in-out infinite, gradient 4s ease infinite;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        `;
        
        container.appendChild(shape);
    }

    // Text reveal animation
    revealText(element, options = {}) {
        const text = element.textContent;
        const words = text.split(' ');
        element.innerHTML = '';
        
        words.forEach((word, index) => {
            const span = document.createElement('span');
            span.textContent = word + ' ';
            span.style.opacity = '0';
            span.style.transform = 'translateY(20px)';
            span.style.transition = 'all 0.6s ease';
            span.style.display = 'inline-block';
            
            element.appendChild(span);
            
            setTimeout(() => {
                span.style.opacity = '1';
                span.style.transform = 'translateY(0)';
            }, index * (options.delay || 100));
        });
    }

    // Magnetic button effect
    setupMagneticButtons() {
        const magneticElements = document.querySelectorAll('.magnetic');
        
        magneticElements.forEach(element => {
            element.addEventListener('mousemove', (e) => {
                const rect = element.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;
                
                element.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px)`;
            });
            
            element.addEventListener('mouseleave', () => {
                element.style.transform = '';
            });
        });
    }

    // 3D tilt effect
    setup3DTilt() {
        const tiltElements = document.querySelectorAll('.tilt-3d');
        
        tiltElements.forEach(element => {
            element.addEventListener('mousemove', (e) => {
                const rect = element.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;
                
                const rotateX = (y - centerY) / 10;
                const rotateY = (centerX - x) / 10;
                
                element.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
            });
            
            element.addEventListener('mouseleave', () => {
                element.style.transform = '';
            });
        });
    }

    // Chain animations
    chainAnimations(animations) {
        return animations.reduce((promise, animation) => {
            return promise.then(() => {
                return new Promise(resolve => {
                    this.playAnimation(animation.element, animation.type);
                    setTimeout(resolve, animation.duration || 1000);
                });
            });
        }, Promise.resolve());
    }

    // Destroy animations
    destroy() {
        this.animations.clear();
        this.observers.forEach(observer => observer.disconnect());
        this.observers.clear();
    }
}

// Initialize animation controller
let animationController;

document.addEventListener('DOMContentLoaded', function() {
    animationController = new AnimationController();
    
    // Setup additional animations
    // Magnetic buttons and 3D tilt effects disabled for normal cursor behavior
    // animationController.setupMagneticButtons();
    // animationController.setup3DTilt();
    
    // Reveal text elements
    const textRevealElements = document.querySelectorAll('.text-reveal');
    textRevealElements.forEach(element => {
        animationController.revealText(element, { delay: 50 });
    });
    
    // Create morphing shapes
    const morphContainers = document.querySelectorAll('.morph-container');
    morphContainers.forEach(container => {
        animationController.createMorphingShape(container);
    });
});

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
    if (animationController) {
        animationController.destroy();
    }
});

// Export for global use
window.AnimationController = AnimationController;

// Animation utilities
const AnimationUtils = {
    // Easing functions
    easing: {
        linear: t => t,
        easeIn: t => t * t,
        easeOut: t => t * (2 - t),
        easeInOut: t => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t,
        easeInCubic: t => t * t * t,
        easeOutCubic: t => (--t) * t * t + 1,
        easeInQuart: t => t * t * t * t,
        easeOutQuart: t => 1 - (--t) * t * t * t,
        easeInQuint: t => t * t * t * t * t,
        easeOutQuint: t => 1 + (--t) * t * t * t * t
    },

    // Animate element property
    animate(element, property, from, to, duration = 1000, easing = 'easeOut') {
        const start = performance.now();
        const easingFunc = this.easing[easing];
        
        const step = (timestamp) => {
            const elapsed = timestamp - start;
            const progress = Math.min(elapsed / duration, 1);
            
            const easedProgress = easingFunc(progress);
            const value = from + (to - from) * easedProgress;
            
            element.style[property] = value + (property.includes('opacity') ? '' : 'px');
            
            if (progress < 1) {
                requestAnimationFrame(step);
            }
        };
        
        requestAnimationFrame(step);
    },

    // Create timeline animation
    timeline() {
        const animations = [];
        
        return {
            add(element, properties, duration, delay = 0) {
                animations.push({ element, properties, duration, delay });
                return this;
            },
            
            play() {
                animations.forEach(({ element, properties, duration, delay }) => {
                    setTimeout(() => {
                        Object.entries(properties).forEach(([prop, value]) => {
                            element.style[prop] = value;
                        });
                    }, delay);
                });
            }
        };
    }
};

window.AnimationUtils = AnimationUtils;